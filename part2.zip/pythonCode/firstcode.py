# count = 0

# while count <= 5:
#     print("hello")
#     count +=1

#     print("end loop")

# n= int(input("enter the number "))
# i = 1
# while i<=10:
#     print(n*1)
#     i+=1

# list = [3,4,6,7,8,9,45,67,89,34,56,67]
# x=4
# index = 0

# while index < 11 :
#     if index == x:
#         index += 1
#         continue
#     print(index)
#     index +=1

# list = ("apple", "banana", "mango", "orange",)
# str = "appleeeegfdhdgfh"

# for char in str:
#     if(char == "g"):
#         print(char)

# sep = range(1, 20, 5)

# for el in sep :
#     print(el)

# for i in range(1, 100, 2):
#     print(i)
# n = int(input("enter number "))
# for i in range(1, 11):
#     # print(n*i)
#     pass

#     print("some usefull code")

# n = 7
# sum = 0
# i = 1
# while i <= n:
#     sum += i
#     i+=1
# print("total sum", sum)

# n = 5
# sum = 1
# i=1
# while i <= n:
#     sum *= i
    # i+=1
    
# print("fectorial = ", sum)

# for i in range(1, n+1):
#     sum*=i
    
# print(sum)

# def calculate(a,b):
#     sum =a+b
#     print(sum) 
    
#     return sum

# calculate(23, 77)

# def print_hello(a,b,c):
#     sum = a+b+c
#     avg = sum/3
#     print(avg)
#     return avg
    
# print_hello(1,4,6)

# heros = ["thor", "iron", "king"]

# def print_len(list):
#     for el in list :
#         print(el, end=" " )
    
# print_len(heros) 

# n = 6
# fact =1
# for i in range(1, n):
    
#     fact *= i
    
# print(fact)

# def convertor(usd_val):
#     pkr_value = usd_val * 283
#     print(usd_val, "USD", pkr_value, "Pkr")
    
# convertor(650)

# def recursion(n):
#      if(n == 0):
#          return
#      print(n)
#      recursion(n-1)
     
# recursion(5)

# def fact(n):
#     if(n == 0 or n==1):
#         return 1
#     else:
#         return n*fact(n-1)
    
# print(fact(5))

# def calulate_sum(n):
#         if(n == 0):
#             return 0
#         return calulate_sum(n-1) + n
        
# sum =calulate_sum(5)
# print(sum)


# def print_list(list, idx=0):
#     if(idx == len(list)):
#         return
#     print(list[idx])
#     print_list(list, idx +1)

# user = ["user", "ali", "haider", "python"]

# print_list(user)

# f = open("demo.txt", "r")

# data = f.read(5)

# print(data)
# print(type(data))
# f.close()

# f = open("demo.txt", "w")

# data = f.write("I want to learn javascript tomorrow.")

# f.close()

# f = open("demo.txt", "a")

# data = f.write("Then I'll move to ReactJs")

# f.close()

# import os

# os.remove("demo.txt")

# with open("prectice.txt", "w") as f:
    
#     f.write("Hi everyon\nwe are learning File I/O")
#     f.write("We are learning Python\n")
#     f.write("Using java")



# with open("prectice.txt", "r") as f:
    
#     data = f.read()
#     new_data = data.replace("java", "Python")
    
#     print(new_data)
    
# with open("prectice.txt", "w") as f:
    
#     f.write(new_data)

# def check_for_word():
#     word = "learning"
#     with open("prectice.txt", "r") as f:
#         data = f.read()
#     if(data.find(word) != -1):
#         print("word found")
#     else:
#         print("word not found")
        
# check_for_word()


# def check_line():
#     word = "learning"
#     data = True
#     line_num = 1
#     with open("prectice.txt", "r") as f:
#         while data:
#             data = f.readline()
#             if(word in data):
#                 print("word found in line", line_num)
#                 return
#             line_num += 1
#     # return -1
        
#     print("word not found")
    
# check_line()

# class Student:
#     name = "Ali Haider"
    
    
# s1 =Student()

# print(s1.name)

# class Student:
#     def __init__(self, fullname):
#         self.name = fullname
#         print("adding new student in database")
        
#     def hello(self):
#         print("Welcome student", self.name)
        
# s1 = Student("ali haider")
# s1.hello()

# class Student:
#     def __init__(self, name, marks):
#         self.name = name
#         self.marks = marks
        
#     def avg_marks(self):
#         sum = 0
#         for val in self.marks:
#             sum+= val
#         print("hi", self.name, "Your average marks is: ", sum /3)
        
        
# s1 = Student("Ali Haider", [98, 97 ,99])
# s1.avg_marks()

# class Student:
#     def __init__(self, name):
#         self.__name = name
        
# s1 = Student("ali")
# print(s1.__name)

# class Car:
#     color = "Yellow"
#     @staticmethod
#     def start():
#         print("Start car")
        
#     def stop():
#         print("Stop Car")
    
# class TayotaCar(Car):
#     def __init__(self, name):
#         self.name = name
        
        
# t1 = TayotaCar("Camry")
# print(t1.name)
# print(t1.color)
# print(t1.start())


# class Student:
#         def __init__(self, phy, chem, math):
             
#                 self.phy = phy
#                 self.chem = chem
#                 self.math = math
                
#         @property       
#         def calculate_percentange(self):
#             return str((self.phy + self.chem + self.math) / 3)+ "%" 
                
                 
# st= Student(98, 97, 99)
# print(st.calculate_percentange)
# st.phy = 86
# print(st.calculate_percentange)         

# todo.py

tasks = []

def add_task(task):
    tasks.append(task)
    print(f'Task "{task}" added!')

def view_tasks():
    if not tasks:
        print("No tasks available.")
    else:
        print("Your tasks:")
        for i, task in enumerate(tasks, 1):
            print(f"{i}. {task}")

def remove_task(task_number):
    if 0 < task_number <= len(tasks):
        removed = tasks.pop(task_number - 1)
        print(f'Task "{removed}" removed!')
    else:
        print("Invalid task number.")

def main():
    while True:
        print("\n1. Add Task\n2. View Tasks\n3. Remove Task\n4. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            task = input("Enter the task: ")
            add_task(task)
        elif choice == '2':
            view_tasks()
        elif choice == '3':
            task_number = int(input("Enter task number to remove: "))
            remove_task(task_number)
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
