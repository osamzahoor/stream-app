from django.db import models
from django.utils import timezone

class Genre(models.Model):
    name = models.CharField(max_length=255)
    
    def __str__(self):
        return self.name
    
class Movie(models.Model):
    title = models.CharField(max_length=255, null=True)
    release_year = models.IntegerField(default=2025)
    number_in_stock = models.IntegerField(default=5)
    daily_rate = models.IntegerField(null=True)  # Allow null values
    date_created = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE, default=1)  # Set a default Genre ID

class Rating(models.Model):
    rating = models.IntegerField(default=5)
    date_created = models.DateTimeField(default=timezone.now)
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, default=1)