from django.urls import path
from django.shortcuts import render
from . import views

urlpatterns = [
    path('contact/', views.contact_view, name='contact'),
    path('success/', lambda request: render(request, 'success.html'), name='success'),
]
