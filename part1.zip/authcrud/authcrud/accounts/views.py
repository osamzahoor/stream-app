from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import RegisterForm, UserEditForm, RegisteredUserForm

def register_view(request):
    form = RegisterForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('login')
    return render(request, 'register.html', {'form': form}) 

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        print(user, "================user")
        if user is not None:
            login(request, user)
            return redirect('user_list')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')
    
@login_required   
def user_list(request):
    users = User.objects.all()
    return render(request, 'user_list.html', {'users': users})

@login_required
def edit_user(request, pk):
    user = get_object_or_404(User, pk=pk)
    form = UserEditForm(request.POST or None, instance=user)
    if form.is_valid():
        form.save()
        return redirect('user_list')
    return render(request, 'edit_user.html', {'form': form})
    
@login_required
def delete_user(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user:
        user.delete()
        return redirect('user_list')
    return render(request, 'delete_user.html', {'user': user})

def register_user(request):
    if request.method == 'POST':
        form = RegisteredUserForm(request.POST)
        if form.is_valid():
            form.save() 
            return redirect('login')
    else:
        form = RegisteredUserForm()  

    return render(request, 'register_user.html', {'form': form})  
 

    