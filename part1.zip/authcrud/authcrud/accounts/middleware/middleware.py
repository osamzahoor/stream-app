from django.shortcuts import redirect, HttpResponse
from django.contrib.auth.models import User
from ..models import RegisteredUser

class LimitUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        print("Middleware triggered for path:", request.path)
        if request.path.endswith('/register-account/') and request.method == 'POST':
            print("Register account POST request detected.")
            user_count = RegisteredUser.objects.count()
            print("Current registered user count:", user_count)
            if user_count >= 5:
                print("User limit exceeded (>= 5), redirecting to login.")
                return redirect('/login/')
        return self.get_response(request)
