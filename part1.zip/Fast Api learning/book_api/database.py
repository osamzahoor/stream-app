# Mock database using a Python dictionary
books = {}
