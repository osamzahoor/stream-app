from pydantic import BaseModel
from typing import Optional

class Book(BaseModel):
    title: str
    author: str
    year: str
    description: Optional[str] = None
    
    
class UpdateBook(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    year: Optional[str] = None
    description: Optional[str] = None