from fastapi import FastAPI
from routes import router

app = FastAPI(
     title="Book Management API",
     description="A simple RESTful API to manage books using FastAPI",
     version="1.0.0"
)

app.include_router(router, prefix="/api")