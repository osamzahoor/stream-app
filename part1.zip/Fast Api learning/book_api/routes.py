from fastapi import APIRouter, HTTPException, status
from model import Book, UpdateBook
from database import books

router = APIRouter()

@router.get("/")
async def root():
    return {"message": "Book apis runing successfully"}

@router.get("/books")
async def get_all_books():
      return books
  
@router.get('/book{book_id}')
async def get_book(book_id: str):
    if book_id not in books:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Book not found")
    return books[book_id]

@router.post('/books{book_id}')
async def create_book(book_id, book: Book):
    if book_id in books:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Book already exist")
    books[book_id] = book
    return book

@router.put("/update-book{book_id}")
async def update_book(book_id: str, book: UpdateBook):
    if book_id not in books:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Book not found")
    if book.title:
        books[book_id].title = book.title
    if book.author:
        books[book_id].author = book.author
    if book.year:
        books[book_id].year = book.year
    if book.description:
        books[book_id].description = book.description
    return books[book_id]

@router.delete("/delete-book{book_id}")
async def delete_book(book_id: str):
      if book_id not in books:
          raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Book not found")
      del books[book_id]
      
      return {"message": "Book deleted successfully"}
          