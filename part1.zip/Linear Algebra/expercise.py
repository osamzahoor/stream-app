# Exercise:
# Implement Euclidean distance, Manhattan distance, and Cosine similarity in vanilla python using numpy.


import numpy as np
 
def euclidean_distance(a, b):
     
     a = np.array(a)
     b = np.array(b)
     return np.sqrt(np.sum((a-b)**2))
 
vec1 = [1, 2, 3]
vec2 = [4, 5, 6]

print("Euclidean Distance:", euclidean_distance(vec1, vec2))

def manhattan_distance(a,b):
    a= np.array(a)
    b = np.array(b)
    return np.sum(np.abs(a-b))

print(" manhattan_distance",  manhattan_distance(vec1, vec2))


def cosine_similarity(a,b):
    a = np.array(a) 
    b = np.array(b)
    dot_product = np.dot(a,b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    return dot_product / (norm_a * norm_b)
    # return np.dot(a,b)/(np.sqrt(np.sum(a**2))*np.sqrt(np.sum(b**2)))
    
print("cosine_similarity", cosine_similarity(vec1, vec2))